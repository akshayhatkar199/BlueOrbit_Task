const strings = {
  API_ROUTE: "http://localhost:3000/api/",
};
export default strings;
